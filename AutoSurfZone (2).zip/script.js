
const adLinks = [
  "https://antautosurf.com/?ref=29085",
  "https://faucetpay.io/?r=2738792",
  "https://socpublic.com/?i=9480820&slide=1",
  "https://bitsbon.com/?ref=5148",
  "https://payeer.com/?session=12482302",
  "https://rollercoin.com/?r=kndi047d",
  "https://viefaucet.com?r=61e83d735cc8356fa4bded97",
  "https://www.coinpayu.com/?r=eduard85",
  "https://www.binance.com/referral/earn-together/refertoearn2000usdc/claim?hl=ru&ref=GRO_14352_KKBV3&utm_medium=web_share_copy&utm_source=referralmode",
  "https://freebitco.in/?r=36730895"
];

let viewCount = 0;
let active = true;

function rotateAds() {
  if (!active) return;
  const iframe = document.getElementById("adFrame");
  const randomIndex = Math.floor(Math.random() * adLinks.length);
  iframe.src = adLinks[randomIndex];
  viewCount++;
  document.getElementById("viewCounter").textContent = "Просмотров: " + viewCount;

  if (viewCount % 5 === 0) {
    document.getElementById("bonusMessage").textContent = "Бонус за активность получен!";
    setTimeout(() => document.getElementById("bonusMessage").textContent = "", 5000);
  }
}

setInterval(rotateAds, 10000);

document.addEventListener("visibilitychange", () => {
  active = document.visibilityState === "visible";
});
